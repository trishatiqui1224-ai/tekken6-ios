E:/Project/Tekken\ 6\ IOS/tekken6-ios/generated/default/codegen.build.stamp: \
  E:/Project/Tekken\ 6\ IOS/tekken6-ios/tekken6_manifest.toml \
  E:/Project/Tekken\ 6\ IOS/tekken6-ios/xex/tekken6_default.xex \
  E:/Project/Tekken\ 6\ IOS/tekken6-ios/tekken6_config.toml
